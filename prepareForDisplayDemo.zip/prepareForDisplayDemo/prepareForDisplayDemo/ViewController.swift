//
//  ViewController.swift
//  prepareForDisplayDemo
//
//  Created by Nitin Bhatia on 05/02/24.
//

import UIKit

let IMAGE_URL = ["https://www.kasandbox.org/programming-images/avatars/spunky-sam.png", "https://www.kasandbox.org/programming-images/avatars/spunky-sam-green.png", "https://www.kasandbox.org/programming-images/avatars/purple-pi.png", "https://www.kasandbox.org/programming-images/avatars/purple-pi-teal.png", "https://www.kasandbox.org/programming-images/avatars/purple-pi-pink.png","https://www.kasandbox.org/programming-images/avatars/primosaur-ultimate.png", "https://www.kasandbox.org/programming-images/avatars/primosaur-tree.png", "https://www.kasandbox.org/programming-images/avatars/primosaur-sapling.png", "https://www.kasandbox.org/programming-images/avatars/orange-juice-squid.png", "https://www.kasandbox.org/programming-images/avatars/old-spice-man.png", "https://www.kasandbox.org/programming-images/avatars/old-spice-man-blue.png", "https://www.kasandbox.org/programming-images/avatars/mr-pants.png","https://www.kasandbox.org/programming-images/avatars/mr-pants-purple.png","https://www.kasandbox.org/programming-images/avatars/mr-pants-green.png","https://www.kasandbox.org/programming-images/avatars/marcimus.png","https://www.kasandbox.org/programming-images/avatars/marcimus-red.png","https://www.kasandbox.org/programming-images/avatars/marcimus-purple.png","https://www.kasandbox.org/programming-images/avatars/marcimus-orange.png","https://www.kasandbox.org/programming-images/avatars/duskpin-ultimate.png","https://www.kasandbox.org/programming-images/avatars/duskpin-tree.png","https://www.kasandbox.org/programming-images/avatars/duskpin-seedling.png","https://www.kasandbox.org/programming-images/avatars/duskpin-seed.png","https://www.kasandbox.org/programming-images/avatars/duskpin-sapling.png","https://fastly.picsum.photos/id/869/200/200.jpg?hmac=Eqnjw4kAS1sFTick74KSN6CBN01wmQg8OpxqbGtdyCU"]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tblView: UITableView!
    
//    var /*selectedImageURL*/ : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return IMAGE_URL.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        var config = cell.defaultContentConfiguration()
        config.text = "\(indexPath.row + 1)"
        config.imageProperties.maximumSize = CGSize(width: 50, height: 50)
        config.imageProperties.reservedLayoutSize = CGSize(width: 50, height: 50)
        config.imageProperties.cornerRadius = 25
        config.imageToTextPadding = 2
        
//        if indexPath.row % 2 == 0 {
//            cell.backgroundColor = .black.withAlphaComponent(0.5)
//        } else {
//            cell.backgroundColor = .black.withAlphaComponent(0.2)
//        }
//        
        cell.contentConfiguration = config
        Task {
            let image = await getImage(from: IMAGE_URL[indexPath.row])
            config.image = await image.byPreparingThumbnail(ofSize: CGSize(width: 30, height: 30))
            cell.contentConfiguration = config
        }
        
        return cell
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "goToImageShowCase", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if  segue.identifier == "goToImageShowCase" {
            let vc = segue.destination as? ImageShowCaseViewController
            vc?.imageURL = IMAGE_URL[tblView.indexPathForSelectedRow?.item ?? 0]
        }
    }
}

extension UIViewController {
    func getImage(from urlString: String) async -> UIImage {
        await withCheckedContinuation {continuation in
        if let url = URL(string: urlString) {
            let urlRequest = URLRequest(url: url)
            
                 URLSession.shared.dataTask(with: urlRequest) { data, response, error in
                    guard
                        let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                        let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                        let data = data, error == nil,
                        let image = UIImage(data: data)
                    else { return }
                     continuation.resume(returning: image)
                }.resume()
            }
        }
    }
}

