//
//  ImageShowCase.swift
//  prepareForDisplayDemo
//
//  Created by Nitin Bhatia on 05/02/24.
//

import UIKit


class ImageShowCaseViewController: UIViewController {
    
    @IBOutlet weak var imgLarge: UIImageView!
    
    var imageURL: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Task {
            let image = await getImage(from: imageURL ?? "")
            imgLarge.image = image.preparingForDisplay()
            //imgLarge.image = await image.byPreparingForDisplay()
        }
    }
}
